# Traffic Analytics System

## Overview

This is a full-stack web application for AI-powered traffic video analysis. The system allows users to upload traffic videos, automatically processes them using machine learning algorithms to detect and analyze vehicle traffic patterns, and provides detailed analytics including vehicle counts, speed measurements, and classification data. The application features a modern React frontend with shadcn/ui components and an Express.js backend with PostgreSQL database integration.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design system and dark theme
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing
- **Component Structure**: Modular component architecture with reusable UI components

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with JSON responses
- **File Handling**: Multer for video file uploads with size limits and type validation
- **ML Processing**: Simulated machine learning processor that generates realistic traffic analysis data
- **Storage**: In-memory storage implementation with interface for database integration

### Database Design
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema**: Two main tables - videos (metadata) and analysis_results (ML output)
- **Video Model**: Stores filename, title, description, file path, duration, file size, and processing status
- **Analysis Model**: Stores vehicle counts, accuracy metrics, processing time, speed data, and vehicle classification
- **Migrations**: Drizzle-kit for database schema management

### Data Flow
- **Upload Process**: Videos uploaded to local filesystem with metadata stored in database
- **Processing Pipeline**: Asynchronous ML processing with status tracking (pending -> processing -> analyzed/error)
- **Analysis Generation**: Realistic traffic data simulation based on video type detection
- **Real-time Updates**: Query invalidation for live status updates

### Authentication & Security
- **File Validation**: Type checking and size limits for video uploads
- **Error Handling**: Comprehensive error handling with proper HTTP status codes
- **CORS**: Configured for cross-origin requests

## External Dependencies

### Database
- **PostgreSQL**: Primary database using Neon serverless PostgreSQL
- **Drizzle ORM**: Type-safe database toolkit with schema validation
- **Connection**: Environment-based database URL configuration

### File Storage
- **Local Filesystem**: Video files stored in local traffic_videos directory
- **Multer**: Express middleware for handling multipart/form-data uploads

### UI Components
- **Radix UI**: Accessible component primitives for complex UI components
- **shadcn/ui**: Pre-built component library with consistent design system
- **Lucide React**: Icon library for consistent iconography

### Development Tools
- **Vite**: Fast build tool with HMR and TypeScript support
- **Replit Plugins**: Development environment enhancements for Replit platform
- **ESBuild**: Fast bundler for production builds

### Utilities
- **TanStack Query**: Server state management and caching
- **React Hook Form**: Form handling with validation
- **Zod**: Runtime type validation and schema parsing
- **date-fns**: Date manipulation utilities
- **clsx/tailwind-merge**: Conditional CSS class utilities