import * as fs from "fs";
import * as path from "path";
import { storage } from "./storage";
import type { InsertVideo } from "../shared/schema";

const SUPPORTED_VIDEO_EXTENSIONS = ['.mp4', '.avi', '.mov', '.mkv', '.webm', '.m4v'];
const TRAFFIC_VIDEOS_DIR = path.join(process.cwd(), "traffic_videos");

interface VideoMetadata {
  filename: string;
  title: string;
  filePath: string;
  fileSize: number;
  duration?: number;
  thumbnail?: string;
}

async function extractVideoMetadata(filePath: string): Promise<VideoMetadata> {
  const filename = path.basename(filePath);
  const stats = fs.statSync(filePath);
  
  // Generate a title from filename (remove extension and clean up)
  const title = path.parse(filename).name
    .replace(/[-_]/g, ' ')
    .replace(/\b\w/g, char => char.toUpperCase());

  return {
    filename,
    title,
    filePath,
    fileSize: stats.size,
    // TODO: Extract duration using ffprobe or similar
    // TODO: Generate thumbnail using ffmpeg or similar
  };
}

async function scanVideoFile(filePath: string): Promise<void> {
  try {
    console.log(`Scanning video: ${filePath}`);
    
    const metadata = await extractVideoMetadata(filePath);
    
    const videoData: InsertVideo = {
      filename: metadata.filename,
      title: metadata.title,
      description: `Traffic video - ${metadata.filename}`,
      filePath: metadata.filePath,
      fileSize: metadata.fileSize,
      status: "pending",
      duration: metadata.duration,
      thumbnail: metadata.thumbnail,
    };

    const video = await storage.createVideo(videoData);
    console.log(`✓ Added video to storage: ${video.title} (${video.id})`);
    
  } catch (error) {
    console.error(`Error scanning video ${filePath}:`, error);
  }
}

export async function scanTrafficVideos(): Promise<void> {
  console.log(`Scanning traffic videos directory: ${TRAFFIC_VIDEOS_DIR}`);

  try {
    // Ensure directory exists
    if (!fs.existsSync(TRAFFIC_VIDEOS_DIR)) {
      fs.mkdirSync(TRAFFIC_VIDEOS_DIR, { recursive: true });
      console.log(`Created traffic_videos directory: ${TRAFFIC_VIDEOS_DIR}`);
      return;
    }

    const files = fs.readdirSync(TRAFFIC_VIDEOS_DIR);
    const videoFiles = files.filter(file => {
      const ext = path.extname(file).toLowerCase();
      return SUPPORTED_VIDEO_EXTENSIONS.includes(ext);
    });

    if (videoFiles.length === 0) {
      console.log("No video files found in traffic_videos directory");
      return;
    }

    console.log(`Found ${videoFiles.length} video file(s)`);

    // Check which videos are already in storage to avoid duplicates
    const existingVideos = await storage.getAllVideos();
    const existingFilePaths = new Set(existingVideos.map(v => v.filePath));

    let newVideosCount = 0;
    for (const file of videoFiles) {
      const filePath = path.join(TRAFFIC_VIDEOS_DIR, file);
      
      if (!existingFilePaths.has(filePath)) {
        await scanVideoFile(filePath);
        newVideosCount++;
      } else {
        console.log(`Skipping already indexed video: ${file}`);
      }
    }

    console.log(`✓ Video scan complete. Added ${newVideosCount} new videos to storage.`);

  } catch (error) {
    console.error("Error scanning traffic videos directory:", error);
  }
}

export async function addSampleTrafficVideos(): Promise<void> {
  console.log("Creating sample traffic video entries for demonstration...");

  const sampleVideos: InsertVideo[] = [
    {
      filename: "highway_traffic_morning_rush.mp4",
      title: "Highway Traffic - Morning Rush",
      description: "Heavy traffic analysis during morning rush hour on Highway 101",
      filePath: path.join(TRAFFIC_VIDEOS_DIR, "highway_traffic_morning_rush.mp4"),
      fileSize: 45600000, // ~45MB
      status: "analyzed",
      duration: 180, // 3 minutes
      thumbnail: null,
    },
    {
      filename: "intersection_busy_downtown.mp4", 
      title: "Downtown Intersection Analysis",
      description: "Busy intersection analysis with pedestrian and vehicle traffic",
      filePath: path.join(TRAFFIC_VIDEOS_DIR, "intersection_busy_downtown.mp4"),
      fileSize: 38200000, // ~38MB
      status: "processing",
      duration: 240, // 4 minutes
      thumbnail: null,
    },
    {
      filename: "residential_street_evening.mp4",
      title: "Residential Street - Evening",
      description: "Low-traffic residential area analysis during evening hours",
      filePath: path.join(TRAFFIC_VIDEOS_DIR, "residential_street_evening.mp4"),
      fileSize: 28900000, // ~29MB
      status: "pending",
      duration: 150, // 2.5 minutes  
      thumbnail: null,
    },
    {
      filename: "freeway_construction_zone.mp4",
      title: "Freeway Construction Zone",
      description: "Traffic pattern analysis near construction zone with lane changes",
      filePath: path.join(TRAFFIC_VIDEOS_DIR, "freeway_construction_zone.mp4"),
      fileSize: 52100000, // ~52MB
      status: "analyzed",
      duration: 300, // 5 minutes
      thumbnail: null,
    },
  ];

  const existingVideos = await storage.getAllVideos();
  if (existingVideos.length > 0) {
    console.log("Videos already exist in storage. Skipping sample creation.");
    return;
  }

  let createdCount = 0;
  for (const videoData of sampleVideos) {
    try {
      const video = await storage.createVideo(videoData);
      console.log(`✓ Created sample video: ${video.title} (${video.id})`);
      createdCount++;
    } catch (error) {
      console.error(`Error creating sample video ${videoData.title}:`, error);
    }
  }

  console.log(`✓ Created ${createdCount} sample traffic videos for demonstration.`);
}