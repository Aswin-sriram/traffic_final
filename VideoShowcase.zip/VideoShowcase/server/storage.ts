import { type Video, type InsertVideo, type AnalysisResult, type InsertAnalysis } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Video operations
  getVideo(id: string): Promise<Video | undefined>;
  getAllVideos(): Promise<Video[]>;
  createVideo(video: InsertVideo): Promise<Video>;
  updateVideoStatus(id: string, status: string, analyzedAt?: Date): Promise<Video | undefined>;
  
  // Analysis operations
  getAnalysisForVideo(videoId: string): Promise<AnalysisResult | undefined>;
  createAnalysis(analysis: InsertAnalysis): Promise<AnalysisResult>;
  
  // Search and filter
  searchVideos(query: string): Promise<Video[]>;
  getVideosByStatus(status: string): Promise<Video[]>;
}

export class MemStorage implements IStorage {
  private videos: Map<string, Video>;
  private analyses: Map<string, AnalysisResult>;

  constructor() {
    this.videos = new Map();
    this.analyses = new Map();
    
    // Initialize with some sample data structure (no mock data)
    this.initializeEmptyState();
  }

  private initializeEmptyState() {
    // Initialize empty maps - no sample data
  }

  async getVideo(id: string): Promise<Video | undefined> {
    return this.videos.get(id);
  }

  async getAllVideos(): Promise<Video[]> {
    return Array.from(this.videos.values()).sort((a, b) => 
      new Date(b.uploadedAt || 0).getTime() - new Date(a.uploadedAt || 0).getTime()
    );
  }

  async createVideo(insertVideo: InsertVideo): Promise<Video> {
    const id = randomUUID();
    const video: Video = { 
      ...insertVideo, 
      id,
      uploadedAt: new Date(),
      analyzedAt: null,
      description: insertVideo.description ?? null,
      duration: insertVideo.duration ?? null,
      thumbnail: insertVideo.thumbnail ?? null,
      fileSize: insertVideo.fileSize ?? null,
      status: insertVideo.status || "pending",
    };
    this.videos.set(id, video);
    return video;
  }

  async updateVideoStatus(id: string, status: string, analyzedAt?: Date): Promise<Video | undefined> {
    const video = this.videos.get(id);
    if (!video) return undefined;
    
    const updatedVideo: Video = { 
      ...video, 
      status,
      analyzedAt: analyzedAt || video.analyzedAt
    };
    this.videos.set(id, updatedVideo);
    return updatedVideo;
  }

  async getAnalysisForVideo(videoId: string): Promise<AnalysisResult | undefined> {
    return Array.from(this.analyses.values()).find(analysis => analysis.videoId === videoId);
  }

  async createAnalysis(insertAnalysis: InsertAnalysis): Promise<AnalysisResult> {
    const id = randomUUID();
    const analysis: AnalysisResult = { 
      ...insertAnalysis, 
      id,
      createdAt: new Date(),
      vehiclesDetected: insertAnalysis.vehiclesDetected ?? null,
      accuracy: insertAnalysis.accuracy ?? null,
      processingTime: insertAnalysis.processingTime ?? null,
      averageSpeed: insertAnalysis.averageSpeed ?? null,
      vehicleClassification: insertAnalysis.vehicleClassification ?? null,
      trafficFlow: insertAnalysis.trafficFlow ?? null,
    };
    this.analyses.set(id, analysis);
    return analysis;
  }

  async searchVideos(query: string): Promise<Video[]> {
    const allVideos = await this.getAllVideos();
    const lowercaseQuery = query.toLowerCase();
    return allVideos.filter(video => 
      video.title.toLowerCase().includes(lowercaseQuery) ||
      video.filename.toLowerCase().includes(lowercaseQuery) ||
      (video.description && video.description.toLowerCase().includes(lowercaseQuery))
    );
  }

  async getVideosByStatus(status: string): Promise<Video[]> {
    const allVideos = await this.getAllVideos();
    return allVideos.filter(video => video.status === status);
  }
}

export const storage = new MemStorage();
