import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertVideoSchema, insertAnalysisSchema } from "@shared/schema";
import { processVideoML } from "./ml-processor";
import multer from "multer";
import path from "path";
import fs from "fs";

// Configure multer for video uploads
const uploadDir = path.join(process.cwd(), "traffic_videos");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({
  dest: uploadDir,
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('video/')) {
      cb(null, true);
    } else {
      cb(new Error('Only video files are allowed'));
    }
  },
  limits: {
    fileSize: 100 * 1024 * 1024 // 100MB limit
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all videos
  app.get("/api/videos", async (req, res) => {
    try {
      const { search, status } = req.query;
      
      let videos;
      if (search) {
        videos = await storage.searchVideos(search as string);
      } else if (status && status !== 'all') {
        videos = await storage.getVideosByStatus(status as string);
      } else {
        videos = await storage.getAllVideos();
      }
      
      res.json(videos);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve videos" });
    }
  });

  // Get single video
  app.get("/api/videos/:id", async (req, res) => {
    try {
      const video = await storage.getVideo(req.params.id);
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }
      res.json(video);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve video" });
    }
  });

  // Upload new video
  app.post("/api/videos", upload.single('video'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No video file provided" });
      }

      const { title, description } = req.body;
      
      const videoData = insertVideoSchema.parse({
        filename: req.file.originalname,
        title: title || req.file.originalname,
        description: description || "",
        filePath: req.file.path,
        fileSize: req.file.size,
        status: "pending"
      });

      const video = await storage.createVideo(videoData);
      
      // Start ML processing asynchronously
      processVideoAsync(video.id);
      
      res.status(201).json(video);
    } catch (error) {
      res.status(400).json({ message: error instanceof Error ? error.message : "Failed to upload video" });
    }
  });

  // Get video analysis
  app.get("/api/videos/:id/analysis", async (req, res) => {
    try {
      const analysis = await storage.getAnalysisForVideo(req.params.id);
      if (!analysis) {
        return res.status(404).json({ message: "Analysis not found" });
      }
      res.json(analysis);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve analysis" });
    }
  });

  // Trigger video reanalysis
  app.post("/api/videos/:id/reanalyze", async (req, res) => {
    try {
      const video = await storage.getVideo(req.params.id);
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }

      await storage.updateVideoStatus(req.params.id, "processing");
      
      // Start ML processing asynchronously
      processVideoAsync(req.params.id);
      
      res.json({ message: "Reanalysis started" });
    } catch (error) {
      res.status(500).json({ message: "Failed to start reanalysis" });
    }
  });

  // Get dashboard statistics
  app.get("/api/stats", async (req, res) => {
    try {
      const allVideos = await storage.getAllVideos();
      
      const stats = {
        totalVideos: allVideos.length,
        analyzed: allVideos.filter(v => v.status === 'analyzed').length,
        processing: allVideos.filter(v => v.status === 'processing').length,
        pending: allVideos.filter(v => v.status === 'pending').length,
        error: allVideos.filter(v => v.status === 'error').length,
        accuracy: "0%" // Will be calculated from analysis results
      };

      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve statistics" });
    }
  });

  // Serve video files
  app.get("/api/videos/:id/stream", async (req, res) => {
    try {
      const video = await storage.getVideo(req.params.id);
      if (!video || !fs.existsSync(video.filePath)) {
        return res.status(404).json({ message: "Video file not found" });
      }

      const stat = fs.statSync(video.filePath);
      const fileSize = stat.size;
      const range = req.headers.range;

      if (range) {
        const parts = range.replace(/bytes=/, "").split("-");
        const start = parseInt(parts[0], 10);
        const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
        const chunksize = (end - start) + 1;
        const file = fs.createReadStream(video.filePath, { start, end });
        const head = {
          'Content-Range': `bytes ${start}-${end}/${fileSize}`,
          'Accept-Ranges': 'bytes',
          'Content-Length': chunksize,
          'Content-Type': 'video/mp4',
        };
        res.writeHead(206, head);
        file.pipe(res);
      } else {
        const head = {
          'Content-Length': fileSize,
          'Content-Type': 'video/mp4',
        };
        res.writeHead(200, head);
        fs.createReadStream(video.filePath).pipe(res);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to stream video" });
    }
  });

  async function processVideoAsync(videoId: string) {
    try {
      await storage.updateVideoStatus(videoId, "processing");
      const result = await processVideoML(videoId);
      
      if (result.success) {
        await storage.createAnalysis(result.analysis);
        await storage.updateVideoStatus(videoId, "analyzed", new Date());
      } else {
        await storage.updateVideoStatus(videoId, "error");
      }
    } catch (error) {
      console.error("ML processing failed:", error);
      await storage.updateVideoStatus(videoId, "error");
    }
  }

  const httpServer = createServer(app);
  return httpServer;
}
