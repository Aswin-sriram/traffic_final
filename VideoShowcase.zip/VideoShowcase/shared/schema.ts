import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, real, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const videos = pgTable("videos", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  filename: text("filename").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  filePath: text("file_path").notNull(),
  thumbnail: text("thumbnail"),
  duration: integer("duration"), // in seconds
  fileSize: integer("file_size"), // in bytes
  status: text("status").notNull().default("pending"), // pending, processing, analyzed, error
  uploadedAt: timestamp("uploaded_at").defaultNow(),
  analyzedAt: timestamp("analyzed_at"),
});

export const analysisResults = pgTable("analysis_results", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  videoId: varchar("video_id").references(() => videos.id).notNull(),
  vehiclesDetected: integer("vehicles_detected").default(0),
  accuracy: real("accuracy").default(0),
  processingTime: real("processing_time"), // in seconds
  averageSpeed: real("average_speed"), // in km/h
  vehicleClassification: jsonb("vehicle_classification"), // {cars: number, trucks: number, etc}
  trafficFlow: jsonb("traffic_flow"), // time series data
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertVideoSchema = createInsertSchema(videos).omit({
  id: true,
  uploadedAt: true,
  analyzedAt: true,
});

export const insertAnalysisSchema = createInsertSchema(analysisResults).omit({
  id: true,
  createdAt: true,
});

export type InsertVideo = z.infer<typeof insertVideoSchema>;
export type Video = typeof videos.$inferSelect;
export type InsertAnalysis = z.infer<typeof insertAnalysisSchema>;
export type AnalysisResult = typeof analysisResults.$inferSelect;
