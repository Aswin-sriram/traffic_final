import { Navigation } from "@/components/navigation";
import { DashboardStats } from "@/components/dashboard-stats";
import { SearchFilter } from "@/components/search-filter";
import { VideoGrid } from "@/components/video-grid";
import { useState } from "react";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortBy, setSortBy] = useState("uploadedAt");

  return (
    <div className="min-h-screen">
      <Navigation />
      
      <main className="container mx-auto px-6 py-8">
        <div className="fade-in">
          <DashboardStats />
        </div>
        
        <div className="fade-in">
          <SearchFilter
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            statusFilter={statusFilter}
            onStatusChange={setStatusFilter}
            sortBy={sortBy}
            onSortChange={setSortBy}
          />
        </div>
        
        <div className="fade-in">
          <VideoGrid
            searchQuery={searchQuery}
            statusFilter={statusFilter}
            sortBy={sortBy}
          />
        </div>
      </main>
    </div>
  );
}
