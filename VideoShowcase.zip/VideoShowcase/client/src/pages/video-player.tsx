import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Download, Share2, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { AnalysisResults } from "@/components/analysis-results";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Video, AnalysisResult } from "@shared/schema";

export default function VideoPlayer() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();

  const { data: video, isLoading: videoLoading } = useQuery<Video>({
    queryKey: ["/api/videos", id],
    enabled: !!id,
  });

  const { data: analysis, isLoading: analysisLoading, refetch: refetchAnalysis } = useQuery<AnalysisResult>({
    queryKey: ["/api/videos", id, "analysis"],
    enabled: !!id,
  });

  const handleReanalyze = async () => {
    try {
      await apiRequest("POST", `/api/videos/${id}/reanalyze`);
      toast({
        title: "Reanalysis Started",
        description: "The video will be reprocessed shortly.",
      });
      refetchAnalysis();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to start reanalysis. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleDownload = () => {
    if (video) {
      const link = document.createElement('a');
      link.href = `/api/videos/${id}/stream`;
      link.download = video.filename;
      link.click();
    }
  };

  const handleShare = async () => {
    try {
      await navigator.share({
        title: video?.title || "Traffic Video",
        url: window.location.href,
      });
    } catch (error) {
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link Copied",
        description: "Video link copied to clipboard.",
      });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "analyzed":
        return <Badge className="bg-green-500">Analyzed</Badge>;
      case "processing":
        return <Badge className="bg-yellow-500">Processing</Badge>;
      case "error":
        return <Badge variant="destructive">Error</Badge>;
      default:
        return <Badge variant="secondary">Pending</Badge>;
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatFileSize = (bytes: number) => {
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(1)} MB`;
  };

  if (videoLoading) {
    return (
      <div className="min-h-screen">
        <header className="border-b border-border bg-background/95 backdrop-blur">
          <div className="container mx-auto px-6 py-4">
            <Skeleton className="h-6 w-32" />
          </div>
        </header>
        <div className="container mx-auto px-6 py-8">
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
            <div className="xl:col-span-2 space-y-6">
              <Skeleton className="aspect-video w-full" />
              <Skeleton className="h-32 w-full" />
            </div>
            <div className="space-y-6">
              <Skeleton className="h-64 w-full" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!video) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">Video not found</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="border-b border-border bg-background/95 backdrop-blur sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              onClick={() => setLocation("/")}
              className="flex items-center space-x-2 text-muted-foreground hover:text-foreground"
              data-testid="button-back"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Back to Gallery</span>
            </Button>
            <div className="flex items-center space-x-4">
              <Button
                variant="secondary"
                onClick={handleDownload}
                data-testid="button-download"
              >
                <Download className="h-4 w-4 mr-2" />
                Download
              </Button>
              <Button
                onClick={handleShare}
                data-testid="button-share"
              >
                <Share2 className="h-4 w-4 mr-2" />
                Share
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          {/* Video Player Section */}
          <div className="xl:col-span-2">
            <Card className="overflow-hidden mb-6">
              <div className="aspect-video bg-black">
                <video
                  className="w-full h-full"
                  controls
                  poster={video.thumbnail || undefined}
                  data-testid="video-player"
                >
                  <source src={`/api/videos/${id}/stream`} type="video/mp4" />
                  Your browser does not support the video tag.
                </video>
              </div>
            </Card>

            {/* Video Info */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <h1 className="text-2xl font-bold text-foreground" data-testid="text-video-title">
                    {video.title}
                  </h1>
                  {getStatusBadge(video.status)}
                </div>
                
                {video.description && (
                  <p className="text-muted-foreground mb-4" data-testid="text-video-description">
                    {video.description}
                  </p>
                )}
                
                <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                  {video.duration && (
                    <span data-testid="text-duration">
                      Duration: {formatDuration(video.duration)}
                    </span>
                  )}
                  {video.fileSize && (
                    <span data-testid="text-filesize">
                      Size: {formatFileSize(video.fileSize)}
                    </span>
                  )}
                  <span data-testid="text-upload-date">
                    Created: {video.uploadedAt ? new Date(video.uploadedAt).toLocaleDateString() : 'Unknown'}
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Analysis Results Section */}
          <div className="space-y-6">
            <AnalysisResults
              videoId={id!}
              analysis={analysis}
              isLoading={analysisLoading}
              onReanalyze={handleReanalyze}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
