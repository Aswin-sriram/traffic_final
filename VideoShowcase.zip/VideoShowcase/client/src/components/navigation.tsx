import { Video, Upload, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";

export function Navigation() {
  const handleUpload = () => {
    toast({
      title: "Upload Feature",
      description: "Video upload functionality would be implemented here.",
    });
  };

  const handleNewAnalysis = () => {
    toast({
      title: "New Analysis",
      description: "New analysis feature would be implemented here.",
    });
  };

  return (
    <header className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <Video className="text-primary-foreground text-xl" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground" data-testid="text-app-title">
                Traffic Analytics
              </h1>
              <p className="text-sm text-muted-foreground">
                AI-Powered Video Analysis
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Button
              variant="secondary"
              onClick={handleUpload}
              data-testid="button-upload"
            >
              <Upload className="h-4 w-4 mr-2" />
              Upload
            </Button>
            <Button
              onClick={handleNewAnalysis}
              data-testid="button-new-analysis"
            >
              <Plus className="h-4 w-4 mr-2" />
              New Analysis
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
