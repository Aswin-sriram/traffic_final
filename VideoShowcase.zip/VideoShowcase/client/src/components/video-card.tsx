import { useLocation } from "wouter";
import { Play, Car, Eye, Clock, TriangleAlert } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Video } from "@shared/schema";

interface VideoCardProps {
  video: Video;
}

export function VideoCard({ video }: VideoCardProps) {
  const [, setLocation] = useLocation();

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "analyzed":
        return <Badge className="bg-green-500 text-white">Analyzed</Badge>;
      case "processing":
        return <Badge className="bg-yellow-500 text-white">Processing</Badge>;
      case "error":
        return <Badge className="bg-red-500 text-white">Error</Badge>;
      default:
        return <Badge variant="secondary">Pending</Badge>;
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatTimeAgo = (date: Date | string) => {
    const now = new Date();
    const uploadDate = new Date(date);
    const diffInHours = Math.floor((now.getTime() - uploadDate.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Just now";
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7) return `${diffInDays} days ago`;
    return uploadDate.toLocaleDateString();
  };

  const handleClick = () => {
    setLocation(`/video/${video.id}`);
  };

  return (
    <Card 
      className="video-card bg-card border border-border rounded-lg overflow-hidden cursor-pointer"
      onClick={handleClick}
      data-testid={`card-video-${video.id}`}
    >
      <div className="aspect-video bg-muted relative">
        {video.thumbnail ? (
          <img 
            src={video.thumbnail} 
            alt={video.title}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-muted flex items-center justify-center">
            <Play className="h-12 w-12 text-muted-foreground" />
          </div>
        )}
        
        <div className="video-overlay">
          <Button 
            size="lg"
            className="w-16 h-16 bg-primary/90 rounded-full flex items-center justify-center hover:bg-primary"
            data-testid={`button-play-${video.id}`}
          >
            <Play className="text-primary-foreground ml-1 h-6 w-6" />
          </Button>
        </div>
        
        <div className="absolute top-3 right-3">
          {getStatusBadge(video.status)}
        </div>
        
        {video.duration && (
          <div className="absolute bottom-3 right-3">
            <Badge variant="secondary" className="bg-black/70 text-white">
              {formatDuration(video.duration)}
            </Badge>
          </div>
        )}
        
        {video.status === "processing" && (
          <div className="absolute bottom-3 left-3">
            <div className="progress-bar w-20 h-1">
              <div className="progress-fill" style={{ width: "65%" }}></div>
            </div>
          </div>
        )}
      </div>
      
      <CardContent className="p-4">
        <h3 className="font-semibold text-foreground mb-2" data-testid={`text-title-${video.id}`}>
          {video.title}
        </h3>
        
        {video.description && (
          <p className="text-muted-foreground text-sm mb-3 line-clamp-2">
            {video.description}
          </p>
        )}
        
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground" data-testid={`text-date-${video.id}`}>
            {video.uploadedAt ? formatTimeAgo(video.uploadedAt) : 'Unknown'}
          </span>
          
          <div className="flex items-center space-x-3">
            {video.status === "analyzed" && (
              <>
                <span className="text-green-500 flex items-center">
                  <Car className="h-3 w-3 mr-1" />
                  0 vehicles
                </span>
                <span className="text-blue-500 flex items-center">
                  <Eye className="h-3 w-3 mr-1" />
                  0%
                </span>
              </>
            )}
            
            {video.status === "processing" && (
              <span className="text-yellow-500 flex items-center">
                <Clock className="h-3 w-3 mr-1" />
                Processing...
              </span>
            )}
            
            {video.status === "error" && (
              <span className="text-red-500 flex items-center">
                <TriangleAlert className="h-3 w-3 mr-1" />
                Analysis failed
              </span>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
