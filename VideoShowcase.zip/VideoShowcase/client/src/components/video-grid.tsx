import { useQuery } from "@tanstack/react-query";
import { VideoCard } from "@/components/video-card";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { Video as VideoIcon } from "lucide-react";
import { Video } from "@shared/schema";

interface VideoGridProps {
  searchQuery: string;
  statusFilter: string;
  sortBy: string;
}

export function VideoGrid({ searchQuery, statusFilter, sortBy }: VideoGridProps) {
  const { data: videos, isLoading } = useQuery<Video[]>({
    queryKey: ["/api/videos", { search: searchQuery, status: statusFilter === 'all' ? undefined : statusFilter }],
  });

  if (isLoading) {
    return (
      <div className="video-grid">
        {Array.from({ length: 6 }).map((_, i) => (
          <Card key={i} className="overflow-hidden">
            <Skeleton className="aspect-video w-full" />
            <div className="p-4 space-y-2">
              <Skeleton className="h-6 w-3/4" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-1/2" />
            </div>
          </Card>
        ))}
      </div>
    );
  }

  if (!videos || videos.length === 0) {
    return (
      <Card className="p-12">
        <CardContent className="text-center">
          <VideoIcon className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">No Videos Found</h3>
          <p className="text-muted-foreground" data-testid="text-no-videos">
            {searchQuery || statusFilter !== 'all' 
              ? "No videos match your search criteria. Try adjusting your filters."
              : "No videos have been uploaded yet. Upload your first traffic video to get started."
            }
          </p>
        </CardContent>
      </Card>
    );
  }

  // Sort videos based on sortBy parameter
  const sortedVideos = [...videos].sort((a, b) => {
    switch (sortBy) {
      case "title":
        return a.title.localeCompare(b.title);
      case "fileSize":
        return (b.fileSize || 0) - (a.fileSize || 0);
      case "analyzedAt":
        if (!a.analyzedAt && !b.analyzedAt) return 0;
        if (!a.analyzedAt) return 1;
        if (!b.analyzedAt) return -1;
        return new Date(b.analyzedAt).getTime() - new Date(a.analyzedAt).getTime();
      default: // uploadedAt
        return new Date(b.uploadedAt ?? 0).getTime() - new Date(a.uploadedAt ?? 0).getTime();
    }
  });

  return (
    <div className="video-grid" data-testid="video-grid">
      {sortedVideos.map((video) => (
        <VideoCard key={video.id} video={video} />
      ))}
    </div>
  );
}
