import { useQuery } from "@tanstack/react-query";
import { Play, CheckCircle, Clock, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export function DashboardStats() {
  interface DashboardStats {
    totalVideos: number;
    analyzed: number;
    processing: number;
    pending: number;
    error: number;
    accuracy: string;
  }

  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/stats"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i} className="metric-card">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-8 w-16" />
                </div>
                <Skeleton className="w-12 h-12 rounded-lg" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const statItems = [
    {
      label: "Total Videos",
      value: stats?.totalVideos || 0,
      icon: Play,
      bgColor: "bg-primary/10",
      iconColor: "text-primary",
      testId: "stat-total-videos"
    },
    {
      label: "Analyzed",
      value: stats?.analyzed || 0,
      icon: CheckCircle,
      bgColor: "bg-green-500/10",
      iconColor: "text-green-500",
      testId: "stat-analyzed"
    },
    {
      label: "Processing",
      value: stats?.processing || 0,
      icon: Clock,
      bgColor: "bg-yellow-500/10",
      iconColor: "text-yellow-500",
      testId: "stat-processing"
    },
    {
      label: "Accuracy",
      value: stats?.accuracy || "0%",
      icon: TrendingUp,
      bgColor: "bg-blue-500/10",
      iconColor: "text-blue-500",
      testId: "stat-accuracy"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
      {statItems.map((stat) => (
        <Card key={stat.label} className="metric-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">{stat.label}</p>
                <p 
                  className="text-2xl font-bold text-foreground" 
                  data-testid={stat.testId}
                >
                  {stat.value}
                </p>
              </div>
              <div className={`w-12 h-12 ${stat.bgColor} rounded-lg flex items-center justify-center`}>
                <stat.icon className={`h-6 w-6 ${stat.iconColor}`} />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
