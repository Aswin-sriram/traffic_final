import { RefreshCw, Car, Truck, Bike, Bus, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { AnalysisResult } from "@shared/schema";

interface AnalysisResultsProps {
  videoId: string;
  analysis?: AnalysisResult;
  isLoading: boolean;
  onReanalyze: () => void;
}

export function AnalysisResults({ videoId, analysis, isLoading, onReanalyze }: AnalysisResultsProps) {
  if (isLoading) {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-32" />
          </CardHeader>
          <CardContent className="space-y-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="flex items-center justify-between">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-6 w-16" />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!analysis) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="text-center">
            <TrendingUp className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">No Analysis Available</h3>
            <p className="text-muted-foreground mb-4">
              This video hasn't been analyzed yet. Click the button below to start the analysis.
            </p>
            <Button onClick={onReanalyze} data-testid="button-analyze">
              <RefreshCw className="h-4 w-4 mr-2" />
              Analyze Video
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  const vehicleClassification = analysis.vehicleClassification as any || {};

  return (
    <div className="space-y-6">
      {/* Analysis Overview */}
      <Card>
        <CardHeader>
          <CardTitle data-testid="text-analysis-title">Analysis Results</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="metric-card">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Vehicles Detected</span>
              <span className="font-semibold text-foreground" data-testid="text-vehicles-detected">
                {analysis.vehiclesDetected || 0}
              </span>
            </div>
          </div>
          
          <div className="metric-card">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Accuracy Score</span>
              <span className="font-semibold text-green-500" data-testid="text-accuracy">
                {((analysis.accuracy || 0) * 100).toFixed(1)}%
              </span>
            </div>
          </div>
          
          <div className="metric-card">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Processing Time</span>
              <span className="font-semibold text-foreground" data-testid="text-processing-time">
                {(analysis.processingTime || 0).toFixed(1)} seconds
              </span>
            </div>
          </div>
          
          {analysis.averageSpeed && (
            <div className="metric-card">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Average Speed</span>
                <span className="font-semibold text-foreground" data-testid="text-average-speed">
                  {analysis.averageSpeed.toFixed(1)} km/h
                </span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Vehicle Classification */}
      <Card>
        <CardHeader>
          <CardTitle>Vehicle Classification</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
              <Car className="h-4 w-4 text-muted-foreground" />
              <span className="text-muted-foreground">Cars</span>
            </div>
            <span className="font-semibold text-foreground" data-testid="text-cars-count">
              {vehicleClassification.cars || 0}
            </span>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <Truck className="h-4 w-4 text-muted-foreground" />
              <span className="text-muted-foreground">Trucks</span>
            </div>
            <span className="font-semibold text-foreground" data-testid="text-trucks-count">
              {vehicleClassification.trucks || 0}
            </span>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
              <Bike className="h-4 w-4 text-muted-foreground" />
              <span className="text-muted-foreground">Motorcycles</span>
            </div>
            <span className="font-semibold text-foreground" data-testid="text-motorcycles-count">
              {vehicleClassification.motorcycles || 0}
            </span>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
              <Bus className="h-4 w-4 text-muted-foreground" />
              <span className="text-muted-foreground">Buses</span>
            </div>
            <span className="font-semibold text-foreground" data-testid="text-buses-count">
              {vehicleClassification.buses || 0}
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Traffic Flow Chart Placeholder */}
      <Card>
        <CardHeader>
          <CardTitle>Traffic Flow Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-32 bg-gradient-to-r from-accent to-primary rounded-lg flex items-center justify-center text-primary-foreground">
            <div className="text-center">
              <TrendingUp className="h-8 w-8 mb-2 mx-auto" />
              <p className="text-sm">Interactive chart would be rendered here</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Reanalyze Button */}
      <Button 
        className="w-full" 
        onClick={onReanalyze}
        data-testid="button-reanalyze"
      >
        <RefreshCw className="h-4 w-4 mr-2" />
        Reanalyze Video
      </Button>
    </div>
  );
}
